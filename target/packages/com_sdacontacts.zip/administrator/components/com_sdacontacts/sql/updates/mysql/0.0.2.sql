alter table `#__sdacontacts_contacts` add `contactPerson` varchar(255) null;
