<?php
/**
 * @package     ${NAMESPACE}
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */

/** @var \Sda\Contacts\Site\View\Contacts\Html  $this       */

$this->addCssFile('media://com_sdacontacts/css/style.css');
echo $this->getRenderedForm();
