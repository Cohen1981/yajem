<?php
/**
 * @package     Sda\Contacts\Site\View\Event
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */

namespace Sda\Contacts\Site\View\Contacts;

use FOF30\View\DataView\Html as BaseHtml;

/**
 * @package     Sda\Contacts\Site\View\Contacts
 *
 * @since       0.0.1
 */
class Html extends BaseHtml
{
}