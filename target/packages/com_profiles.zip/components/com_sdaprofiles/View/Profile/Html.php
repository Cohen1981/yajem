<?php
/**
 * @package     Sda\Profiles\Site\View\Profile
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */

namespace Sda\Profiles\Site\View\Profile;

use FOF30\View\DataView\Html as BaseHtml;

class Html extends BaseHtml
{
}