DROP TABLE IF EXISTS `#__sdaprofiles_profiles`;
DROP TABLE IF EXISTS `#__sdaprofiles_fittings`;
DROP TABLE IF EXISTS `#__sdaprofiles_fitting_images`;
DROP TABLE IF EXISTS `#__sdaprofiles_fitting_types`;
