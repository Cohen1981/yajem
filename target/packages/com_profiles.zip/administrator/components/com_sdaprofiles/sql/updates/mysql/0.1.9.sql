ALTER TABLE `#__sdaprofiles_profiles`
    ADD `defaultGroup` tinyint(1) unsigned default 0;