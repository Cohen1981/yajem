alter table `#__sdaprofiles_profiles`
    add `mailOnNew` tinyint null,
    add `mailOnEdited` tinyint null;