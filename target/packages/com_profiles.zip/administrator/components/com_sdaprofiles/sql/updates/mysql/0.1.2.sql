alter table `#__sdaprofiles_fittings`
    add `image` varchar(255) null;