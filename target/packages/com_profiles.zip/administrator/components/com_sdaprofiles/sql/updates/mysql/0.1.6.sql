alter table `#__sdaprofiles_fitting_images`
    add `description` VARCHAR(1024) null;