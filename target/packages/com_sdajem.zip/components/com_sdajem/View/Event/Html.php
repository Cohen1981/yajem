<?php
/**
 * @package     Sda\Jem\Site\View\Event
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */

namespace Sda\Jem\Site\View\Event;

use FOF30\View\DataView\Html as BaseHtml;

/**
 * @package     Sda\Jem\Site\View\Event
 *
 * @since       0.0.1
 */
class Html extends BaseHtml
{
}