<?php
/**
 * @package     Sda\Jem\Site\Model
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */

namespace Sda\Jem\Site\Model;

use Sda\Jem\Admin\Model\Contact as AdminContact;

/**
 * @package     Sda\Jem\Site\Model
 *
 * @since       0.0.1
 */
class Contact extends AdminContact
{

}