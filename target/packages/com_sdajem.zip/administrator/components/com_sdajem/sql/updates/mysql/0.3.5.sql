ALTER TABLE `#__sdajem_events`
    ADD `svg` BLOB NULL DEFAULT NULL;