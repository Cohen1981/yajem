alter table `#__sdajem_events` alter column `fittingProfile` set default NULL;
alter table `#__sdajem_events` alter column `useFittings` set default NULL;