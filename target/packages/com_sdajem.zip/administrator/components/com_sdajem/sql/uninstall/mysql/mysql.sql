DROP TABLE IF EXISTS `#__sdajem_locations`;
DROP TABLE IF EXISTS `#__sdajem_events`;
DROP TABLE IF EXISTS `#__sdajem_attendees`;
DROP TABLE IF EXISTS `#__sdajem_comments`;
DROP TABLE IF EXISTS `#__sdajem_attachments`;
DROP TABLE IF EXISTS `#__sdajem_categories`;
DROP TABLE IF EXISTS `#__sdajem_mailings`;